# fftleds_N1024
Sony Spresense ambient audio fourier analysis in LEDs with N=1024 fft size
