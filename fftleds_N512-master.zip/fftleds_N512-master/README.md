# fftleds_N512
Sony Spresense ambient audio fourier analysis in LEDs with N=512 fft size
